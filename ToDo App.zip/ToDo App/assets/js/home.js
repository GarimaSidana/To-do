//Just to add java Script to file
console.log('Script is loaded');